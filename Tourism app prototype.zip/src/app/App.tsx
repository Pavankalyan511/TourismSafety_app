import { useState } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { KYCScreen } from './components/KYCScreen';
import { TouristIDScreen } from './components/TouristIDScreen';
import { PermissionsScreen } from './components/PermissionsScreen';
import { MainDashboard } from './components/MainDashboard';
import { AlertScreen } from './components/AlertScreen';
import { EFIRScreen } from './components/EFIRScreen';
import { StatusScreen } from './components/StatusScreen';
import { TouristMapScreen } from './components/TouristMapScreen';
import { LocalInfoScreen } from './components/LocalInfoScreen';
import { AttractionsScreen } from './components/AttractionsScreen';

type Screen = 'welcome' | 'kyc' | 'tourist-id' | 'permissions' | 'dashboard' | 'alert' | 'efir' | 'status' | 'tourist-map' | 'local-info' | 'attractions';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('welcome');

  const handleScreenNavigation = (screen: Screen) => {
    setCurrentScreen(screen);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'welcome':
        return <WelcomeScreen onNext={() => handleScreenNavigation('kyc')} />;
      
      case 'kyc':
        return (
          <KYCScreen 
            onNext={() => handleScreenNavigation('tourist-id')}
            onBack={() => handleScreenNavigation('welcome')}
          />
        );
      
      case 'tourist-id':
        return <TouristIDScreen onNext={() => handleScreenNavigation('permissions')} />;
      
      case 'permissions':
        return (
          <PermissionsScreen 
            onNext={() => handleScreenNavigation('dashboard')}
            onBack={() => handleScreenNavigation('tourist-id')}
          />
        );
      
      case 'dashboard':
        return (
          <MainDashboard 
            onAlertPress={() => handleScreenNavigation('alert')} 
            onEFIRPress={() => handleScreenNavigation('efir')}
            onStatusPress={() => handleScreenNavigation('status')}
            onTouristMapPress={() => handleScreenNavigation('tourist-map')}
            onLocalInfoPress={() => handleScreenNavigation('local-info')}
            onAttractionsPress={() => handleScreenNavigation('attractions')}
          />
        );
      
      case 'alert':
        return (
          <AlertScreen 
            onCancel={() => handleScreenNavigation('dashboard')}
            onBackToDashboard={() => handleScreenNavigation('dashboard')}
          />
        );
      
      case 'efir':
        return (
          <EFIRScreen 
            onBack={() => handleScreenNavigation('dashboard')}
            onHome={() => handleScreenNavigation('dashboard')}
          />
        );
      
      case 'status':
        return (
          <StatusScreen 
            onBack={() => handleScreenNavigation('dashboard')}
          />
        );
      
      case 'tourist-map':
        return (
          <TouristMapScreen 
            onBack={() => handleScreenNavigation('dashboard')}
          />
        );
      
      case 'local-info':
        return (
          <LocalInfoScreen 
            onBack={() => handleScreenNavigation('dashboard')}
          />
        );
      
      case 'attractions':
        return (
          <AttractionsScreen 
            onBack={() => handleScreenNavigation('dashboard')}
          />
        );
      
      default:
        return <WelcomeScreen onNext={() => handleScreenNavigation('kyc')} />;
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      {renderScreen()}
    </div>
  );
}