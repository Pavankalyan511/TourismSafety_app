import { Button } from "./ui/button";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { useState } from "react";

interface KYCScreenProps {
  onNext: () => void;
  onBack: () => void;
}

export function KYCScreen({ onNext, onBack }: KYCScreenProps) {
  const [docType, setDocType] = useState("");
  const [docNumber, setDocNumber] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);

  const handleVerify = () => {
    if (docType && docNumber) {
      setIsVerifying(true);
      // Simulate verification process
      setTimeout(() => {
        setIsVerifying(false);
        onNext();
      }, 2000);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <Button 
          variant="ghost" 
          onClick={onBack}
          className="text-blue-600"
        >
          ← Back
        </Button>
        <h1 className="text-xl text-blue-900">Identity Verification</h1>
        <div className="w-16"></div>
      </div>

      {/* Progress */}
      <div className="px-6 mb-8">
        <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
          <span>Step 1 of 3</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-blue-600 h-2 rounded-full w-1/3"></div>
        </div>
      </div>

      {/* KYC Form */}
      <div className="px-6 space-y-6">
        <Card>
          <CardHeader>
            <h2 className="text-center text-gray-800">Complete KYC Verification</h2>
            <p className="text-center text-sm text-gray-500">
              Required for tourist ID generation
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="docType">Document Type</Label>
              <Select value={docType} onValueChange={setDocType}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select document type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="aadhaar">Aadhaar Card</SelectItem>
                  <SelectItem value="passport">Passport</SelectItem>
                  <SelectItem value="license">Driving License</SelectItem>
                  <SelectItem value="voter">Voter ID</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="docNumber">Document Number</Label>
              <Input
                id="docNumber"
                value={docNumber}
                onChange={(e) => setDocNumber(e.target.value)}
                placeholder="Enter document number"
                className="mt-1"
              />
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <div className="flex">
                <span className="text-yellow-600 mr-2">⚠️</span>
                <div>
                  <p className="text-sm text-yellow-800">Security Notice</p>
                  <p className="text-xs text-yellow-700 mt-1">
                    Your information is encrypted and verified through government databases
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Verification Steps */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="mb-4 text-gray-800">Verification Process</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 text-sm">1</span>
                </div>
                <span className="text-sm text-gray-600">Document verification</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center">
                  <span className="text-gray-400 text-sm">2</span>
                </div>
                <span className="text-sm text-gray-400">Government database check</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center">
                  <span className="text-gray-400 text-sm">3</span>
                </div>
                <span className="text-sm text-gray-400">Tourist ID generation</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Action Button */}
      <div className="px-6 pt-8 pb-8">
        <Button 
          onClick={handleVerify}
          disabled={!docType || !docNumber || isVerifying}
          className="w-full bg-blue-600 hover:bg-blue-700 py-4"
        >
          {isVerifying ? "Verifying..." : "Verify Identity"}
        </Button>
      </div>
    </div>
  );
}