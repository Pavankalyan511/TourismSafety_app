import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { ArrowLeft, MapPin, Signal, CheckCircle, RefreshCw } from "lucide-react";

interface StatusScreenProps {
  onBack: () => void;
}

export function StatusScreen({ onBack }: StatusScreenProps) {
  const currentTime = new Date().toLocaleTimeString();
  const currentDate = new Date().toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <div className="bg-blue-600 text-white px-6 py-6 rounded-b-3xl shadow-lg">
        <div className="flex items-center mb-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="text-white hover:bg-white/20 mr-3 p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-xl">System Status</h1>
            <p className="text-blue-100 text-sm">Real-time safety monitoring</p>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
            TID-2024-MH-789456
          </Badge>
          <div className="text-right text-sm">
            <p className="text-blue-100">{currentDate}</p>
            <p className="text-white">{currentTime}</p>
          </div>
        </div>
      </div>

      {/* Overall Status */}
      <div className="px-6 py-6">
        <Card className="bg-green-50 border-green-200 mb-6">
          <CardContent className="p-6 text-center">
            <div className="w-16 h-16 bg-green-500 rounded-full mx-auto mb-4 flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-xl text-green-800 mb-2">All Systems Active</h2>
            <p className="text-green-700 text-sm">Your safety monitoring is fully operational</p>
          </CardContent>
        </Card>

        {/* Detailed Status Cards */}
        <div className="space-y-4">
          {/* Location Status */}
          <Card className="bg-green-50 border-green-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between text-green-800">
                <div className="flex items-center space-x-2">
                  <MapPin className="w-5 h-5" />
                  <span>Location Tracking</span>
                </div>
                <Badge className="bg-green-500 text-white">Active</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-green-700">GPS Accuracy</span>
                  <span className="text-sm text-green-800">± 3 meters</span>
                </div>
                <Progress value={95} className="h-2" />
                <div className="flex justify-between items-center text-xs text-green-600">
                  <span>Last updated: 2 seconds ago</span>
                  <span>Satellites: 12/12</span>
                </div>
                <div className="bg-white/50 rounded-lg p-3">
                  <p className="text-xs text-green-700 mb-1">Current Location</p>
                  <p className="text-sm text-green-800">Gateway of India, Mumbai</p>
                  <p className="text-xs text-green-600">Lat: 18.9220, Lng: 72.8347</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Signal Status */}
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between text-blue-800">
                <div className="flex items-center space-x-2">
                  <Signal className="w-5 h-5" />
                  <span>Network Signal</span>
                </div>
                <Badge className="bg-blue-500 text-white">Good</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-blue-700">Signal Strength</span>
                  <span className="text-sm text-blue-800">-68 dBm</span>
                </div>
                <Progress value={85} className="h-2" />
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/50 rounded-lg p-3">
                    <p className="text-xs text-blue-700 mb-1">Mobile Network</p>
                    <p className="text-sm text-blue-800">4G LTE</p>
                    <p className="text-xs text-blue-600">Carrier: Jio</p>
                  </div>
                  <div className="bg-white/50 rounded-lg p-3">
                    <p className="text-xs text-blue-700 mb-1">WiFi</p>
                    <p className="text-sm text-blue-800">Connected</p>
                    <p className="text-xs text-blue-600">Speed: 50 Mbps</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Route Verification */}
          <Card className="bg-purple-50 border-purple-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between text-purple-800">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5" />
                  <span>Route Verification</span>
                </div>
                <Badge className="bg-purple-500 text-white">Verified</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-purple-700">Safety Score</span>
                  <span className="text-sm text-purple-800">9.2/10</span>
                </div>
                <Progress value={92} className="h-2" />
                <div className="bg-white/50 rounded-lg p-3">
                  <p className="text-xs text-purple-700 mb-2">Route Analysis</p>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-purple-600">Well-lit areas</span>
                      <span className="text-green-600">✓ Yes</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-purple-600">Police presence</span>
                      <span className="text-green-600">✓ Active</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-purple-600">Tourist-friendly</span>
                      <span className="text-green-600">✓ Verified</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-purple-600">Emergency access</span>
                      <span className="text-green-600">✓ Available</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Emergency Contacts */}
        <Card className="mt-6 bg-red-50 border-red-200">
          <CardHeader>
            <CardTitle className="text-red-800">Emergency Services</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/50 rounded-lg p-3 text-center">
                <span className="text-2xl mb-2 block">🚔</span>
                <p className="text-sm text-red-800">Police</p>
                <p className="text-xs text-red-600">100</p>
              </div>
              <div className="bg-white/50 rounded-lg p-3 text-center">
                <span className="text-2xl mb-2 block">🏥</span>
                <p className="text-sm text-red-800">Medical</p>
                <p className="text-xs text-red-600">108</p>
              </div>
              <div className="bg-white/50 rounded-lg p-3 text-center">
                <span className="text-2xl mb-2 block">🚒</span>
                <p className="text-sm text-red-800">Fire</p>
                <p className="text-xs text-red-600">101</p>
              </div>
              <div className="bg-white/50 rounded-lg p-3 text-center">
                <span className="text-2xl mb-2 block">👮</span>
                <p className="text-sm text-red-800">Tourist Helpline</p>
                <p className="text-xs text-red-600">1363</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Refresh Button */}
        <div className="flex justify-center mt-6">
          <Button 
            variant="outline" 
            className="flex items-center space-x-2"
            onClick={() => window.location.reload()}
          >
            <RefreshCw className="w-4 h-4" />
            <span>Refresh Status</span>
          </Button>
        </div>
      </div>
    </div>
  );
}