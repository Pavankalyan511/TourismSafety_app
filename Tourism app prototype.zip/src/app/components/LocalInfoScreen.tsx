import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Info, Clock, Phone, MapPin, ArrowLeft, AlertTriangle, Wifi, Car, Utensils } from "lucide-react";

interface LocalInfoScreenProps {
  onBack: () => void;
}

export function LocalInfoScreen({ onBack }: LocalInfoScreenProps) {
  const emergencyContacts = [
    { service: "Police", number: "100", description: "Emergency police services" },
    { service: "Fire Brigade", number: "101", description: "Fire emergency services" },
    { service: "Ambulance", number: "108", description: "Medical emergency services" },
    { service: "Tourist Helpline", number: "1363", description: "24/7 tourist assistance" },
    { service: "Women Safety", number: "181", description: "Women in distress helpline" }
  ];

  const importantPlaces = [
    { name: "Mumbai Central Railway Station", address: "Dr. Dadabhai Naoroji Rd, Mumbai Central", distance: "8.2 km" },
    { name: "Chhatrapati Shivaji International Airport", address: "Mumbai, Maharashtra 400099", distance: "28.5 km" },
    { name: "General Post Office", address: "Shahid Bhagat Singh Rd, Fort, Mumbai", distance: "1.5 km" },
    { name: "Bombay High Court", address: "Fort, Mumbai, Maharashtra 400001", distance: "2.1 km" }
  ];

  const localTips = [
    {
      category: "Transportation",
      icon: <Car className="w-5 h-5" />,
      tips: [
        "Use Uber/Ola for safe taxi rides",
        "Mumbai local trains are fastest for long distances",
        "Avoid rush hours: 8-11 AM and 5-8 PM",
        "Keep exact change for buses and autos"
      ]
    },
    {
      category: "Dining",
      icon: <Utensils className="w-5 h-5" />,
      tips: [
        "Try street food at Mohammed Ali Road",
        "Always drink bottled water",
        "Check restaurant hygiene ratings",
        "Tip 10% at restaurants is customary"
      ]
    },
    {
      category: "Safety",
      icon: <AlertTriangle className="w-5 h-5" />,
      tips: [
        "Keep copies of important documents",
        "Avoid isolated areas after 10 PM",
        "Use official taxi stands near hotels",
        "Stay alert in crowded markets"
      ]
    },
    {
      category: "Connectivity",
      icon: <Wifi className="w-5 h-5" />,
      tips: [
        "Free WiFi available at malls and cafes",
        "Buy local SIM for better connectivity",
        "Download offline maps before traveling",
        "Keep power bank for emergencies"
      ]
    }
  ];

  const currentWeather = {
    temperature: "28°C",
    condition: "Partly Cloudy",
    humidity: "76%",
    visibility: "8 km"
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-600 to-orange-700 text-white px-6 py-6 rounded-b-3xl shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onBack}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl">Local Information</h1>
              <p className="text-orange-100 text-sm">Essential local knowledge</p>
            </div>
          </div>
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <Info className="w-6 h-6" />
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
            📍 Mumbai, Maharashtra
          </Badge>
          <Badge variant="secondary" className="bg-green-500 text-white">
            Updated Today
          </Badge>
        </div>
      </div>

      {/* Current Weather */}
      <div className="px-6 py-6">
        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="mb-1">Current Weather</h3>
                <p className="text-2xl mb-1">{currentWeather.temperature}</p>
                <p className="text-blue-100 text-sm">{currentWeather.condition}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-blue-100">Humidity: {currentWeather.humidity}</p>
                <p className="text-sm text-blue-100">Visibility: {currentWeather.visibility}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="px-6 pb-8">
        <Tabs defaultValue="emergency" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="emergency">Emergency</TabsTrigger>
            <TabsTrigger value="places">Places</TabsTrigger>
            <TabsTrigger value="tips">Tips</TabsTrigger>
            <TabsTrigger value="time">Time</TabsTrigger>
          </TabsList>
          
          <TabsContent value="emergency" className="space-y-3 mt-4">
            <h3 className="text-lg text-gray-800 mb-3">Emergency Contacts</h3>
            {emergencyContacts.map((contact, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center">
                        <Phone className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <p className="text-gray-800">{contact.service}</p>
                        <p className="text-sm text-gray-600">{contact.description}</p>
                      </div>
                    </div>
                    <Button className="bg-red-500 hover:bg-red-600">
                      Call {contact.number}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
          
          <TabsContent value="places" className="space-y-3 mt-4">
            <h3 className="text-lg text-gray-800 mb-3">Important Places</h3>
            {importantPlaces.map((place, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center mt-1">
                        <MapPin className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <p className="text-gray-800 mb-1">{place.name}</p>
                        <p className="text-sm text-gray-600 mb-2">{place.address}</p>
                        <p className="text-sm text-orange-600">Distance: {place.distance}</p>
                      </div>
                    </div>
                    <Button size="sm" variant="outline">
                      Directions
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
          
          <TabsContent value="tips" className="space-y-4 mt-4">
            <h3 className="text-lg text-gray-800 mb-3">Local Tips & Advice</h3>
            {localTips.map((tipCategory, index) => (
              <Card key={index}>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center space-x-2 text-base">
                    {tipCategory.icon}
                    <span>{tipCategory.category}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <ul className="space-y-2">
                    {tipCategory.tips.map((tip, tipIndex) => (
                      <li key={tipIndex} className="flex items-start space-x-2 text-sm">
                        <span className="text-orange-500 mt-1">•</span>
                        <span className="text-gray-700">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
          
          <TabsContent value="time" className="space-y-3 mt-4">
            <h3 className="text-lg text-gray-800 mb-3">Time & Schedule Information</h3>
            
            <Card>
              <CardContent className="p-4">
                <div className="text-center mb-4">
                  <div className="flex items-center justify-center space-x-2 mb-2">
                    <Clock className="w-6 h-6 text-orange-500" />
                    <h4 className="text-lg">Current Local Time</h4>
                  </div>
                  <p className="text-3xl text-gray-800 mb-1">2:45 PM</p>
                  <p className="text-sm text-gray-600">Saturday, September 27, 2025</p>
                  <p className="text-sm text-gray-600">India Standard Time (IST)</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Business Hours</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Banks:</span>
                    <span className="text-gray-600">10:00 AM - 4:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Government Offices:</span>
                    <span className="text-gray-600">9:30 AM - 6:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shops & Markets:</span>
                    <span className="text-gray-600">10:00 AM - 10:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Restaurants:</span>
                    <span className="text-gray-600">12:00 PM - 11:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tourist Attractions:</span>
                    <span className="text-gray-600">9:00 AM - 6:00 PM</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}