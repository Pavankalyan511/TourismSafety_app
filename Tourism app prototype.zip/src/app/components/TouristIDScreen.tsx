import { Button } from "./ui/button";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";
import { useState, useEffect } from "react";

interface TouristIDScreenProps {
  onNext: () => void;
}

export function TouristIDScreen({ onNext }: TouristIDScreenProps) {
  const [isGenerating, setIsGenerating] = useState(true);
  const [touristId] = useState("TID-2024-MH-789456");

  useEffect(() => {
    // Simulate ID generation process
    const timer = setTimeout(() => {
      setIsGenerating(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  if (isGenerating) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex items-center justify-center">
        <div className="text-center px-6">
          <div className="w-16 h-16 mx-auto mb-6 bg-blue-600 rounded-full flex items-center justify-center animate-pulse">
            <span className="text-white text-2xl">🆔</span>
          </div>
          <h2 className="text-xl text-gray-800 mb-2">Generating Tourist ID</h2>
          <p className="text-gray-600 mb-6">Please wait while we process your information...</p>
          <div className="flex justify-center space-x-1">
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <div className="text-center pt-12 pb-8">
        <div className="w-16 h-16 mx-auto mb-4 bg-green-600 rounded-full flex items-center justify-center">
          <span className="text-white text-2xl">✓</span>
        </div>
        <h1 className="text-2xl text-gray-800 mb-2">ID Generated Successfully</h1>
        <p className="text-gray-600">Your tourist ID has been created</p>
      </div>

      {/* Progress */}
      <div className="px-6 mb-8">
        <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
          <span>Step 2 of 3</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-blue-600 h-2 rounded-full w-2/3"></div>
        </div>
      </div>

      {/* Tourist ID Card */}
      <div className="px-6 mb-8">
        <Card className="bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-xl">
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-blue-100 text-sm">Government of India</p>
                <h3 className="text-xl">Tourist ID</h3>
              </div>
              <Badge variant="secondary" className="bg-white/20 text-white">
                Active
              </Badge>
            </div>
            
            <div className="space-y-2 mb-4">
              <p className="text-2xl font-mono tracking-wider">{touristId}</p>
              <p className="text-blue-100 text-sm">Valid for current visit</p>
            </div>

            <div className="flex justify-between items-end">
              <div>
                <p className="text-xs text-blue-100">Issued by</p>
                <p className="text-sm">Tourism Department</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-blue-100">Issue Date</p>
                <p className="text-sm">{new Date().toLocaleDateString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Information */}
      <div className="px-6 space-y-4 mb-8">
        <Card>
          <CardContent className="pt-6">
            <h3 className="mb-4 text-gray-800">What's Next?</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 text-sm">📍</span>
                </div>
                <div>
                  <p className="text-sm">Location Permissions</p>
                  <p className="text-xs text-gray-500">Enable for safety tracking</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 text-sm">📞</span>
                </div>
                <div>
                  <p className="text-sm">Emergency Contacts</p>
                  <p className="text-xs text-gray-500">For immediate assistance</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex">
            <span className="text-green-600 mr-2">ℹ️</span>
            <div>
              <p className="text-sm text-green-800">Important</p>
              <p className="text-xs text-green-700 mt-1">
                Keep your Tourist ID handy. It will be required for accessing tourist facilities and emergency services.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Action Button */}
      <div className="px-6 pb-8">
        <Button 
          onClick={onNext}
          className="w-full bg-blue-600 hover:bg-blue-700 py-4"
        >
          Continue Setup
        </Button>
      </div>
    </div>
  );
}