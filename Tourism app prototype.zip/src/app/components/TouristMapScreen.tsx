import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { MapPin, Navigation, Phone, Star, Clock, ArrowLeft } from "lucide-react";

interface TouristMapScreenProps {
  onBack: () => void;
}

export function TouristMapScreen({ onBack }: TouristMapScreenProps) {
  const nearbyPlaces = [
    {
      id: 1,
      name: "Gateway of India",
      category: "Monument",
      distance: "0.5 km",
      rating: 4.6,
      isOpen: true,
      phone: "+91-22-2202-6364",
      description: "Iconic arch-monument overlooking the Arabian Sea"
    },
    {
      id: 2,
      name: "Taj Mahal Palace Hotel",
      category: "Hotel",
      distance: "0.3 km",
      rating: 4.8,
      isOpen: true,
      phone: "+91-22-6665-3366",
      description: "Luxury heritage hotel"
    },
    {
      id: 3,
      name: "Chhatrapati Shivaji Museum",
      category: "Museum",
      distance: "1.2 km",
      rating: 4.4,
      isOpen: false,
      phone: "+91-22-2284-4484",
      description: "Premier art and history museum"
    },
    {
      id: 4,
      name: "Colaba Causeway Market",
      category: "Shopping",
      distance: "0.8 km",
      rating: 4.2,
      isOpen: true,
      phone: "N/A",
      description: "Popular street shopping destination"
    },
    {
      id: 5,
      name: "Marine Drive",
      category: "Promenade",
      distance: "2.1 km",
      rating: 4.7,
      isOpen: true,
      phone: "N/A",
      description: "Scenic waterfront promenade"
    }
  ];

  const emergencyServices = [
    { name: "Police Station", distance: "0.4 km", phone: "100" },
    { name: "Hospital", distance: "0.7 km", phone: "108" },
    { name: "Tourist Helpline", distance: "N/A", phone: "1363" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-6 rounded-b-3xl shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onBack}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl">Tourist Map</h1>
              <p className="text-green-100 text-sm">Explore nearby attractions</p>
            </div>
          </div>
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <MapPin className="w-6 h-6" />
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
            📍 Colaba, Mumbai
          </Badge>
          <Badge variant="secondary" className="bg-blue-500 text-white">
            GPS Active
          </Badge>
        </div>
      </div>

      {/* Map Placeholder */}
      <div className="px-6 py-6">
        <Card className="bg-gradient-to-br from-green-100 to-blue-100 border-2 border-green-200">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="w-full h-48 bg-gradient-to-br from-green-200 to-blue-200 rounded-lg flex items-center justify-center mb-4">
                <div className="text-center">
                  <MapPin className="w-12 h-12 text-green-600 mx-auto mb-2" />
                  <p className="text-gray-700">Interactive Map View</p>
                  <p className="text-sm text-gray-600">Your location & nearby places</p>
                </div>
              </div>
              <div className="flex items-center justify-center space-x-4">
                <Button size="sm" className="bg-green-600 hover:bg-green-700">
                  <Navigation className="w-4 h-4 mr-2" />
                  Get Directions
                </Button>
                <Button size="sm" variant="outline">
                  Share Location
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Emergency Services */}
      <div className="px-6 pb-4">
        <h3 className="text-lg text-gray-800 mb-3">Emergency Services</h3>
        <div className="grid grid-cols-1 gap-2">
          {emergencyServices.map((service, index) => (
            <Card key={index} className="bg-red-50 border-red-200">
              <CardContent className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
                      <Phone className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="text-red-800">{service.name}</p>
                      <p className="text-sm text-red-600">{service.distance}</p>
                    </div>
                  </div>
                  <Button size="sm" className="bg-red-500 hover:bg-red-600">
                    Call {service.phone}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Nearby Places */}
      <div className="px-6 pb-8">
        <h3 className="text-lg text-gray-800 mb-3">Nearby Places</h3>
        <div className="space-y-3">
          {nearbyPlaces.map((place) => (
            <Card key={place.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="text-gray-800">{place.name}</h4>
                      <Badge variant="secondary" className="text-xs">
                        {place.category}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{place.description}</p>
                    <div className="flex items-center space-x-4 text-sm">
                      <span className="flex items-center space-x-1 text-gray-600">
                        <MapPin className="w-3 h-3" />
                        <span>{place.distance}</span>
                      </span>
                      <span className="flex items-center space-x-1 text-yellow-600">
                        <Star className="w-3 h-3 fill-current" />
                        <span>{place.rating}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span className={place.isOpen ? "text-green-600" : "text-red-600"}>
                          {place.isOpen ? "Open" : "Closed"}
                        </span>
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="outline" className="flex-1">
                    <Navigation className="w-3 h-3 mr-1" />
                    Directions
                  </Button>
                  {place.phone !== "N/A" && (
                    <Button size="sm" variant="outline">
                      <Phone className="w-3 h-3 mr-1" />
                      Call
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}