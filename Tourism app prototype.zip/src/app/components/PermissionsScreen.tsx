import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Switch } from "./ui/switch";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useState } from "react";

interface PermissionsScreenProps {
  onNext: () => void;
  onBack: () => void;
}

export function PermissionsScreen({
  onNext,
  onBack,
}: PermissionsScreenProps) {
  const [locationEnabled, setLocationEnabled] = useState(false);
  const [emergencyContact1, setEmergencyContact1] =
    useState("");
  const [emergencyContact2, setEmergencyContact2] =
    useState("");

  const canProceed = locationEnabled && emergencyContact1;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-blue-600"
        >
          ← Back
        </Button>
        <h1 className="text-xl text-blue-900">Permissions</h1>
        <div className="w-16"></div>
      </div>

      {/* Progress */}
      <div className="px-6 mb-8">
        <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
          <span>Step 3 of 3</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-blue-600 h-2 rounded-full w-full"></div>
        </div>
      </div>

      {/* Permissions */}
      <div className="px-6 space-y-6">
        {/* Location Permission */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-lg text-gray-800 mb-2">
                  Location Tracking
                </h3>
                <p className="text-sm text-gray-600 mb-4">
                  Enable real-time location tracking for your
                  safety and security. This helps emergency
                  services locate you quickly if needed.
                </p>
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <span>🔒</span>
                  <span>
                    Your location data is encrypted and secure
                  </span>
                </div>
              </div>
              <Switch
                checked={locationEnabled}
                onCheckedChange={setLocationEnabled}
                className="ml-4"
              />
            </div>

            {locationEnabled && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                <p className="text-sm text-green-800 flex items-center">
                  <span className="mr-2">✓</span>
                  Location tracking enabled
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Emergency Contacts */}
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg text-gray-800 mb-2">
              Emergency Contacts
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Add trusted contacts who will be notified in case
              of emergency
            </p>

            <div className="space-y-4">
              <div>
                <Label htmlFor="contact1">
                  Primary Emergency Contact *
                </Label>
                <Input
                  id="contact1"
                  value={emergencyContact1}
                  onChange={(e) =>
                    setEmergencyContact1(e.target.value)
                  }
                  placeholder="+91 98765 43210"
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="contact2">
                  Secondary Emergency Contact
                </Label>
                <Input
                  id="contact2"
                  value={emergencyContact2}
                  onChange={(e) =>
                    setEmergencyContact2(e.target.value)
                  }
                  placeholder="+91 98765 43210"
                  className="mt-1"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Safety Features */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-6">
            <h3 className="text-lg text-blue-900 mb-3">
              Safety Features Enabled
            </h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-sm text-blue-800">
                <span>🚨</span>
                <span>Emergency alert button</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-blue-800">
                <span>👮</span>
                <span>Direct connection to police</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-blue-800">
                <span>🏥</span>
                <span>Hospital emergency services</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-blue-800">
                <span>📍</span>
                <span>Real-time location sharing</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {!locationEnabled && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex">
              <span className="text-yellow-600 mr-2">⚠️</span>
              <div>
                <p className="text-sm text-yellow-800">
                  Location Required
                </p>
                <p className="text-xs text-yellow-700 mt-1">
                  Location tracking must be enabled for
                  emergency services to function properly.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Action Button */}
      <div className="px-6 pt-8 pb-8">
        <Button
          onClick={onNext}
          disabled={!canProceed}
          className="w-full bg-blue-600 hover:bg-blue-700 py-4 disabled:opacity-50"
        >
          Complete Setup
        </Button>
        <p className="text-center text-xs text-gray-500 mt-2">
          By continuing, you agree to our privacy policy and
          terms of service
        </p>
      </div>
    </div>
  );
}