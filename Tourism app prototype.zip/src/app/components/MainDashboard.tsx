import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { useState } from "react";

interface MainDashboardProps {
  onAlertPress: () => void;
  onEFIRPress: () => void;
  onStatusPress: () => void;
  onTouristMapPress: () => void;
  onLocalInfoPress: () => void;
  onAttractionsPress: () => void;
}

export function MainDashboard({ onAlertPress, onEFIRPress, onStatusPress, onTouristMapPress, onLocalInfoPress, onAttractionsPress }: MainDashboardProps) {
  const [isPressed, setIsPressed] = useState(false);

  const handleSmartButtonPress = () => {
    setIsPressed(true);
    onAlertPress();
    // Reset the pressed state after animation
    setTimeout(() => setIsPressed(false), 200);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <div className="bg-blue-600 text-white px-6 py-6 rounded-b-3xl shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl">Smart Tourism</h1>
            <p className="text-blue-100 text-sm">Stay Safe, Explore More</p>
          </div>
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <span className="text-xl">👤</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
            TID-2024-MH-789456
          </Badge>
          <Badge variant="secondary" className="bg-green-500 text-white">
            Active
          </Badge>
        </div>
      </div>

      {/* Quick Status Overview */}
      <div className="px-6 py-6">
        <Card 
          className="bg-gradient-to-r from-green-500 to-blue-500 text-white cursor-pointer hover:from-green-600 hover:to-blue-600 transition-colors"
          onClick={onStatusPress}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="mb-1">System Status</h3>
                <div className="flex items-center space-x-4 text-sm">
                  <span className="flex items-center space-x-1">
                    <span>📍</span>
                    <span>Active</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <span>📶</span>
                    <span>Good</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <span>✓</span>
                    <span>Verified</span>
                  </span>
                </div>
              </div>
              <div className="text-right">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <span className="text-xl">→</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Smart Button */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="text-center">
          <h2 className="text-xl text-gray-800 mb-2">Emergency Alert</h2>
          <p className="text-gray-600 text-sm mb-8">Press in case of emergency</p>
          
          <div className="relative">
            {/* Ripple effect */}
            <div className="absolute inset-0 rounded-full border-4 border-blue-300 animate-ping"></div>
            <div className="absolute inset-4 rounded-full border-2 border-blue-200 animate-ping" style={{animationDelay: '0.5s'}}></div>
            
            {/* Main Button */}
            <Button
              onClick={handleSmartButtonPress}
              className={`w-32 h-32 rounded-full bg-blue-600 hover:bg-blue-700 shadow-2xl transform transition-transform ${
                isPressed ? 'scale-95' : 'hover:scale-105'
              }`}
            >
              <span className="text-white text-4xl">!</span>
            </Button>
          </div>
          
          <p className="text-xs text-gray-500 mt-6">
            This will alert Police Department and Hospital services
          </p>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-6 pb-8">
        <h3 className="text-lg text-gray-800 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-3">
          <Card 
            className="bg-gradient-to-r from-green-500 to-green-600 text-white cursor-pointer hover:from-green-600 hover:to-green-700 transition-colors"
            onClick={onTouristMapPress}
          >
            <CardContent className="p-4 text-center">
              <span className="text-2xl mb-2 block">🗺️</span>
              <p className="text-sm">Tourist Map</p>
            </CardContent>
          </Card>
          
          <Card 
            className="bg-gradient-to-r from-orange-500 to-orange-600 text-white cursor-pointer hover:from-orange-600 hover:to-orange-700 transition-colors"
            onClick={onLocalInfoPress}
          >
            <CardContent className="p-4 text-center">
              <span className="text-2xl mb-2 block">ℹ️</span>
              <p className="text-sm">Local Info</p>
            </CardContent>
          </Card>
          
          <Card 
            className="bg-gradient-to-r from-purple-500 to-purple-600 text-white cursor-pointer hover:from-purple-600 hover:to-purple-700 transition-colors"
            onClick={onAttractionsPress}
          >
            <CardContent className="p-4 text-center">
              <span className="text-2xl mb-2 block">🏛️</span>
              <p className="text-sm">Attractions</p>
            </CardContent>
          </Card>
          
          <Card 
            className="bg-gradient-to-r from-red-500 to-red-600 text-white cursor-pointer hover:from-red-600 hover:to-red-700 transition-colors"
            onClick={onEFIRPress}
          >
            <CardContent className="p-4 text-center">
              <span className="text-2xl mb-2 block">📋</span>
              <p className="text-sm">e-FIR Portal</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}