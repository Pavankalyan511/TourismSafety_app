import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { useState, useEffect } from "react";

interface AlertScreenProps {
  onCancel: () => void;
  onBackToDashboard: () => void;
}

export function AlertScreen({ onCancel, onBackToDashboard }: AlertScreenProps) {
  const [timeLeft, setTimeLeft] = useState(10);
  const [isActive, setIsActive] = useState(false);
  const [alertSent, setAlertSent] = useState(false);

  useEffect(() => {
    if (timeLeft > 0 && !alertSent) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !alertSent) {
      setIsActive(true);
      setAlertSent(true);
    }
  }, [timeLeft, alertSent]);

  const handleCancel = () => {
    setTimeLeft(0);
    setAlertSent(false);
    onCancel();
  };

  if (alertSent) {
    return (
      <div className="min-h-screen bg-red-600 text-white">
        {/* Alert Active Header */}
        <div className="px-6 py-8 text-center">
          <div className="w-20 h-20 mx-auto mb-4 bg-white/20 rounded-full flex items-center justify-center animate-pulse">
            <span className="text-3xl">🚨</span>
          </div>
          <h1 className="text-2xl mb-2">EMERGENCY ALERT ACTIVE</h1>
          <p className="text-red-100">Help is on the way</p>
        </div>

        {/* Location Info */}
        <div className="px-6 mb-6">
          <Card className="bg-white/10 border-white/20 text-white">
            <CardContent className="p-4">
              <h3 className="mb-3">Your Location Shared With:</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-lg">👮</span>
                    <div>
                      <p className="font-medium">Police Department</p>
                      <p className="text-sm text-red-100">Central Police Station</p>
                    </div>
                  </div>
                  <Badge className="bg-green-500 text-white">
                    Connected
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-lg">🏥</span>
                    <div>
                      <p className="font-medium">Hospital Services</p>
                      <p className="text-sm text-red-100">City General Hospital</p>
                    </div>
                  </div>
                  <Badge className="bg-green-500 text-white">
                    Connected
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-lg">📞</span>
                    <div>
                      <p className="font-medium">Emergency Contacts</p>
                      <p className="text-sm text-red-100">+91 98765 43210</p>
                    </div>
                  </div>
                  <Badge className="bg-yellow-500 text-white">
                    Notified
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Status Updates */}
        <div className="px-6 space-y-3 mb-8">
          <div className="bg-white/10 rounded-lg p-3">
            <div className="flex items-center space-x-2 text-sm">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              <span>Location shared successfully</span>
              <span className="text-xs text-red-200">Just now</span>
            </div>
          </div>
          <div className="bg-white/10 rounded-lg p-3">
            <div className="flex items-center space-x-2 text-sm">
              <span className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></span>
              <span>Emergency services dispatched</span>
              <span className="text-xs text-red-200">30 sec ago</span>
            </div>
          </div>
          <div className="bg-white/10 rounded-lg p-3">
            <div className="flex items-center space-x-2 text-sm">
              <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></span>
              <span>Tourist ID verified</span>
              <span className="text-xs text-red-200">45 sec ago</span>
            </div>
          </div>
        </div>

        {/* Safety Instructions */}
        <div className="px-6 mb-8">
          <Card className="bg-yellow-500/20 border-yellow-400/30">
            <CardContent className="p-4">
              <h3 className="text-yellow-100 mb-2">Safety Instructions</h3>
              <div className="space-y-1 text-sm text-yellow-100">
                <p>• Stay in a safe location if possible</p>
                <p>• Keep your phone with you</p>
                <p>• Wait for emergency services to arrive</p>
                <p>• Follow instructions from authorities</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="px-6 space-y-3">
          <Button 
            onClick={onBackToDashboard}
            className="w-full bg-white text-red-600 hover:bg-gray-100 py-4"
          >
            I'm Safe - End Alert
          </Button>
          <Button 
            variant="outline"
            className="w-full border-white/30 text-white hover:bg-white/10 py-3"
          >
            Call Police Directly
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-orange-500 text-white">
      {/* Countdown Header */}
      <div className="px-6 py-8 text-center">
        <div className="w-24 h-24 mx-auto mb-4 bg-white/20 rounded-full flex items-center justify-center">
          <span className="text-4xl">{timeLeft}</span>
        </div>
        <h1 className="text-2xl mb-2">Emergency Alert</h1>
        <p className="text-orange-100">Activating in {timeLeft} seconds</p>
      </div>

      {/* Cancel Option */}
      <div className="px-6 mb-8">
        <Card className="bg-white/10 border-white/20 text-white">
          <CardContent className="p-4 text-center">
            <h3 className="mb-3">Press by mistake?</h3>
            <p className="text-sm text-orange-100 mb-4">
              Cancel now to prevent emergency services from being alerted
            </p>
            <Button 
              onClick={handleCancel}
              className="w-full bg-white text-orange-600 hover:bg-gray-100"
            >
              Cancel Alert
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* What Will Happen */}
      <div className="px-6">
        <h3 className="text-lg mb-4">What will happen when activated:</h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
              <span className="text-sm">📍</span>
            </div>
            <p className="text-sm">Your exact location will be shared</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
              <span className="text-sm">👮</span>
            </div>
            <p className="text-sm">Police will be immediately notified</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
              <span className="text-sm">🏥</span>
            </div>
            <p className="text-sm">Hospital emergency services alerted</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
              <span className="text-sm">📞</span>
            </div>
            <p className="text-sm">Emergency contacts will be called</p>
          </div>
        </div>
      </div>
    </div>
  );
}