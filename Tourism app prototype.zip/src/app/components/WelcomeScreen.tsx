import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface WelcomeScreenProps {
  onNext: () => void;
}

export function WelcomeScreen({ onNext }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex flex-col">
      {/* Header */}
      <div className="text-center pt-12 pb-8">
        <div className="w-20 h-20 mx-auto mb-6 bg-blue-600 rounded-full flex items-center justify-center">
          <span className="text-white text-2xl">🏛️</span>
        </div>
        <h1 className="text-3xl text-blue-900 mb-2">Smart Tourism</h1>
        <p className="text-blue-600">Safe Travel, Smart Experience</p>
      </div>

      {/* Hero Image */}
      <div className="flex-1 px-6 mb-8">
        <Card className="overflow-hidden shadow-lg">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1671375159250-b5c5fca0183a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3VyaXN0JTIwZGVzdGluYXRpb24lMjBpbmRpYSUyMG1vbnVtZW50fGVufDF8fHx8MTc1ODUyOTg3M3ww&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Tourist destination"
            className="w-full h-64 object-cover"
          />
        </Card>
      </div>

      {/* Features */}
      <div className="px-6 space-y-4 mb-8">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
            <span className="text-green-600">✓</span>
          </div>
          <p className="text-gray-700">Real-time location tracking</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
            <span className="text-green-600">✓</span>
          </div>
          <p className="text-gray-700">Emergency alert system</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
            <span className="text-green-600">✓</span>
          </div>
          <p className="text-gray-700">Verified route guidance</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
            <span className="text-green-600">✓</span>
          </div>
          <p className="text-gray-700">24/7 safety support</p>
        </div>
      </div>

      {/* Action Button */}
      <div className="px-6 pb-8">
        <Button 
          onClick={onNext}
          className="w-full bg-blue-600 hover:bg-blue-700 py-4"
        >
          Get Started
        </Button>
        <p className="text-center text-sm text-gray-500 mt-4">
          Secure and government approved
        </p>
      </div>
    </div>
  );
}