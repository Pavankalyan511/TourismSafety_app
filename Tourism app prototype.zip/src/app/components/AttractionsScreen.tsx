import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Star, Clock, MapPin, Camera, ArrowLeft, Heart, Share2, Ticket } from "lucide-react";
import { useState } from "react";

interface AttractionsScreenProps {
  onBack: () => void;
}

export function AttractionsScreen({ onBack }: AttractionsScreenProps) {
  const [favorites, setFavorites] = useState<number[]>([1, 3]);

  const toggleFavorite = (id: number) => {
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(fav => fav !== id) : [...prev, id]
    );
  };

  const popularAttractions = [
    {
      id: 1,
      name: "Gateway of India",
      category: "Monument",
      rating: 4.6,
      reviews: 45289,
      distance: "0.5 km",
      duration: "1-2 hours",
      entryFee: "Free",
      openTime: "24/7",
      description: "Iconic arch-monument built to commemorate the visit of King George V and Queen Mary to Mumbai.",
      highlights: ["Photography", "Architecture", "History", "Boat rides"],
      bestTime: "Early morning or sunset"
    },
    {
      id: 2,
      name: "Marine Drive",
      category: "Promenade",
      rating: 4.7,
      reviews: 38567,
      distance: "2.1 km",
      duration: "2-3 hours",
      entryFee: "Free",
      openTime: "24/7",
      description: "A 3.6-kilometer-long boulevard along the coast, perfect for evening walks and scenic views.",
      highlights: ["Sunset views", "Walking", "Street food", "Photography"],
      bestTime: "Evening (5-7 PM)"
    },
    {
      id: 3,
      name: "Chhatrapati Shivaji Museum",
      category: "Museum",
      rating: 4.4,
      reviews: 12453,
      distance: "1.2 km",
      duration: "2-4 hours",
      entryFee: "₹70",
      openTime: "10:15 AM - 6:00 PM",
      description: "Premier art and history museum showcasing ancient Indian history, sculptures, and decorative arts.",
      highlights: ["Artifacts", "Sculptures", "Paintings", "Natural history"],
      bestTime: "Morning (10-12 PM)"
    },
    {
      id: 4,
      name: "Hanging Gardens",
      category: "Garden",
      rating: 4.2,
      reviews: 8934,
      distance: "7.8 km",
      duration: "1-2 hours",
      entryFee: "Free",
      openTime: "5:00 AM - 9:00 PM",
      description: "Terraced gardens perched at the top of Malabar Hill, offering panoramic views of the city.",
      highlights: ["City views", "Gardens", "Jogging", "Photography"],
      bestTime: "Early morning or evening"
    },
    {
      id: 5,
      name: "Crawford Market",
      category: "Market",
      rating: 4.0,
      reviews: 15672,
      distance: "3.5 km",
      duration: "2-3 hours",
      entryFee: "Free",
      openTime: "11:00 AM - 8:00 PM",
      description: "Historic market known for fresh produce, spices, and unique shopping experience.",
      highlights: ["Shopping", "Local culture", "Food", "Architecture"],
      bestTime: "Morning (11 AM - 1 PM)"
    }
  ];

  const categories = [
    { name: "All", count: popularAttractions.length },
    { name: "Monument", count: 1 },
    { name: "Museum", count: 1 },
    { name: "Garden", count: 1 },
    { name: "Market", count: 1 },
    { name: "Promenade", count: 1 }
  ];

  const featuredTours = [
    {
      name: "Mumbai Heritage Walk",
      duration: "4 hours",
      price: "₹1,200",
      rating: 4.8,
      includes: ["Guide", "Refreshments", "Entry tickets"]
    },
    {
      name: "Bollywood Studios Tour",
      duration: "6 hours",
      price: "₹2,500",
      rating: 4.6,
      includes: ["Transportation", "Lunch", "Studio access"]
    },
    {
      name: "Street Food Tour",
      duration: "3 hours",
      price: "₹800",
      rating: 4.9,
      includes: ["Food tastings", "Guide", "Local transport"]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-700 text-white px-6 py-6 rounded-b-3xl shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onBack}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl">Tourist Attractions</h1>
              <p className="text-purple-100 text-sm">Discover amazing places</p>
            </div>
          </div>
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <Camera className="w-6 h-6" />
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
            📍 Mumbai, Maharashtra
          </Badge>
          <Badge variant="secondary" className="bg-green-500 text-white">
            {popularAttractions.length} Places
          </Badge>
        </div>
      </div>

      <div className="px-6 py-6">
        <Tabs defaultValue="attractions" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="attractions">Attractions</TabsTrigger>
            <TabsTrigger value="tours">Tours</TabsTrigger>
          </TabsList>
          
          <TabsContent value="attractions" className="mt-4">
            {/* Category Filter */}
            <div className="flex space-x-2 mb-4 overflow-x-auto pb-2">
              {categories.map((category, index) => (
                <Badge 
                  key={index}
                  variant={index === 0 ? "default" : "secondary"}
                  className={`whitespace-nowrap cursor-pointer ${
                    index === 0 ? "bg-purple-600" : "hover:bg-purple-100"
                  }`}
                >
                  {category.name} ({category.count})
                </Badge>
              ))}
            </div>

            {/* Attractions List */}
            <div className="space-y-4">
              {popularAttractions.map((attraction) => (
                <Card key={attraction.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-0">
                    {/* Image Placeholder */}
                    <div className="h-48 bg-gradient-to-br from-purple-200 to-blue-200 rounded-t-lg relative">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Camera className="w-12 h-12 text-purple-600" />
                      </div>
                      <div className="absolute top-3 right-3 flex space-x-2">
                        <Button
                          size="sm"
                          variant="secondary"
                          className="w-8 h-8 p-0 bg-white/90 hover:bg-white"
                          onClick={() => toggleFavorite(attraction.id)}
                        >
                          <Heart 
                            className={`w-4 h-4 ${
                              favorites.includes(attraction.id) 
                                ? "fill-red-500 text-red-500" 
                                : "text-gray-600"
                            }`} 
                          />
                        </Button>
                        <Button
                          size="sm"
                          variant="secondary"
                          className="w-8 h-8 p-0 bg-white/90 hover:bg-white"
                        >
                          <Share2 className="w-4 h-4 text-gray-600" />
                        </Button>
                      </div>
                      <div className="absolute top-3 left-3">
                        <Badge className="bg-purple-600">
                          {attraction.category}
                        </Badge>
                      </div>
                    </div>

                    <div className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <h3 className="text-lg text-gray-800 mb-1">{attraction.name}</h3>
                          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                            <span className="flex items-center space-x-1">
                              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                              <span>{attraction.rating}</span>
                              <span>({attraction.reviews.toLocaleString()})</span>
                            </span>
                            <span className="flex items-center space-x-1">
                              <MapPin className="w-3 h-3" />
                              <span>{attraction.distance}</span>
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-600 mb-3">{attraction.description}</p>
                      
                      <div className="grid grid-cols-2 gap-4 mb-3 text-sm">
                        <div>
                          <span className="text-gray-500">Duration:</span>
                          <span className="ml-1 text-gray-700">{attraction.duration}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Entry Fee:</span>
                          <span className="ml-1 text-gray-700">{attraction.entryFee}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Open:</span>
                          <span className="ml-1 text-gray-700">{attraction.openTime}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Best Time:</span>
                          <span className="ml-1 text-gray-700">{attraction.bestTime}</span>
                        </div>
                      </div>

                      <div className="mb-3">
                        <p className="text-sm text-gray-500 mb-2">Highlights:</p>
                        <div className="flex flex-wrap gap-1">
                          {attraction.highlights.map((highlight, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {highlight}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <Button className="flex-1 bg-purple-600 hover:bg-purple-700">
                          <MapPin className="w-4 h-4 mr-2" />
                          Get Directions
                        </Button>
                        <Button variant="outline" className="flex-1">
                          <Clock className="w-4 h-4 mr-2" />
                          Plan Visit
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="tours" className="mt-4">
            <h3 className="text-lg text-gray-800 mb-4">Featured Tours</h3>
            <div className="space-y-4">
              {featuredTours.map((tour, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="text-gray-800 mb-1">{tour.name}</h4>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                          <span className="flex items-center space-x-1">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                            <span>{tour.rating}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>{tour.duration}</span>
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-lg text-purple-600">{tour.price}</p>
                        <p className="text-xs text-gray-500">per person</p>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-sm text-gray-500 mb-2">Includes:</p>
                      <div className="flex flex-wrap gap-1">
                        {tour.includes.map((item, itemIndex) => (
                          <Badge key={itemIndex} variant="outline" className="text-xs">
                            {item}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <Button className="flex-1 bg-purple-600 hover:bg-purple-700">
                        <Ticket className="w-4 h-4 mr-2" />
                        Book Now
                      </Button>
                      <Button variant="outline">
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}