import { Button } from "./ui/button";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { useState } from "react";
import exampleImage from 'figma:asset/aed067d6efd4b01e1c2f5efa37936b5e5cc5f2a6.png';

interface EFIRScreenProps {
  onBack: () => void;
  onHome: () => void;
}

export function EFIRScreen({ onBack, onHome }: EFIRScreenProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    complaintType: "",
    details: ""
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    if (formData.name && formData.email && formData.phone && formData.complaintType && formData.details) {
      setIsSubmitting(true);
      // Simulate submission process
      setTimeout(() => {
        setIsSubmitting(false);
        setIsSubmitted(true);
      }, 2000);
    }
  };

  const canSubmit = formData.name && formData.email && formData.phone && formData.complaintType && formData.details;

  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-blue-500 via-blue-600 to-blue-700 relative overflow-hidden"
      style={{
        backgroundImage: `url(${exampleImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundBlendMode: 'overlay'
      }}
    >
      {/* Background overlay for better readability */}
      <div className="absolute inset-0 bg-blue-600/80"></div>
      
      {/* Header */}
      <div className="relative z-10 flex items-center justify-between p-6 text-white">
        <div>
          <h1 className="text-2xl">e-FIR Portal</h1>
        </div>
        <Button 
          onClick={onHome}
          variant="ghost" 
          className="text-white hover:bg-white/20 flex items-center space-x-2"
        >
          <span>🏠</span>
          <span>Home</span>
        </Button>
      </div>

      <div className="relative z-10 px-6 pb-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Form */}
          <Card className="lg:col-span-2 bg-white/95 backdrop-blur shadow-xl">
            <CardHeader>
              <h2 className="text-xl text-gray-800">File a Complaint</h2>
            </CardHeader>
            <CardContent className="space-y-4">
              {!isSubmitted ? (
                <>
                  {/* Name Field */}
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-600 text-sm">👤</span>
                    </div>
                    <div className="flex-1">
                      <Label htmlFor="name">Name</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        placeholder="Enter your full name"
                        className="mt-1"
                      />
                    </div>
                  </div>

                  {/* Email Field */}
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-600 text-sm">✉️</span>
                    </div>
                    <div className="flex-1">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        placeholder="Enter your email"
                        className="mt-1"
                      />
                    </div>
                  </div>

                  {/* Phone Field */}
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-600 text-sm">📞</span>
                    </div>
                    <div className="flex-1">
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        placeholder="Enter your phone number"
                        className="mt-1"
                      />
                    </div>
                  </div>

                  {/* Complaint Type */}
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-600 text-sm">⚠️</span>
                    </div>
                    <div className="flex-1">
                      <Label htmlFor="complaintType">Complaint type</Label>
                      <Select value={formData.complaintType} onValueChange={(value) => handleInputChange('complaintType', value)}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select complaint type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="theft">Theft/Robbery</SelectItem>
                          <SelectItem value="fraud">Tourist Fraud</SelectItem>
                          <SelectItem value="harassment">Harassment</SelectItem>
                          <SelectItem value="overcharging">Overcharging</SelectItem>
                          <SelectItem value="accommodation">Accommodation Issues</SelectItem>
                          <SelectItem value="transport">Transport Problems</SelectItem>
                          <SelectItem value="guide">Tour Guide Issues</SelectItem>
                          <SelectItem value="safety">Safety Concerns</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Details */}
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-600 text-sm">📝</span>
                    </div>
                    <div className="flex-1">
                      <Label htmlFor="details">Details</Label>
                      <Textarea
                        id="details"
                        value={formData.details}
                        onChange={(e) => handleInputChange('details', e.target.value)}
                        placeholder="Describe the issue"
                        className="mt-1 min-h-24"
                      />
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-4 text-center">
                    <Button 
                      onClick={handleSubmit}
                      disabled={!canSubmit || isSubmitting}
                      className="bg-blue-600 hover:bg-blue-700 px-12 py-3"
                    >
                      {isSubmitting ? "Submitting..." : "Submit"}
                    </Button>
                  </div>
                </>
              ) : (
                /* Success State */
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-green-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <span className="text-white text-2xl">✓</span>
                  </div>
                  <h3 className="text-xl text-gray-800 mb-2">Complaint Filed Successfully</h3>
                  <p className="text-gray-600 mb-4">Your complaint has been submitted. You will receive updates via email and SMS.</p>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                    <p className="text-sm text-blue-800">
                      <strong>Complaint ID:</strong> FIR-2024-{Math.random().toString(36).substr(2, 9).toUpperCase()}
                    </p>
                  </div>
                  <Button 
                    onClick={onHome}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Back to Dashboard
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Status Panel */}
          <Card className="bg-white/90 backdrop-blur shadow-xl">
            <CardHeader>
              <h3 className="text-lg text-gray-800">Status</h3>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs">✓</span>
                  </div>
                  <span className="text-sm text-blue-800">Filed</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-gray-400 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs">⏳</span>
                  </div>
                  <span className="text-sm text-gray-600">Under Review</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-gray-400 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs">✓</span>
                  </div>
                  <span className="text-sm text-gray-600">Action Taken</span>
                </div>
              </div>

              <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h4 className="text-sm text-yellow-800 mb-2">Important Notes</h4>
                <ul className="text-xs text-yellow-700 space-y-1">
                  <li>• Keep your complaint ID safe</li>
                  <li>• Response time: 24-48 hours</li>
                  <li>• For urgent cases, call emergency helpline</li>
                  <li>• Track status via SMS/Email</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Emergency Notice */}
        <Card className="mt-6 bg-red-50 border-red-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <span className="text-red-600 text-lg">🚨</span>
              <div>
                <h4 className="text-red-800 mb-1">Emergency Situations</h4>
                <p className="text-sm text-red-700">
                  For immediate danger or life-threatening situations, use the Emergency Alert button in the main dashboard 
                  or call the local emergency services directly.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}